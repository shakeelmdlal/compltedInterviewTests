import react, { useEffect, useState } from "react"

function TableList() {
    const [tableData, settableData] = useState([]);
    const [tabsData, settabsData] = useState([]);
    const [activeTab, setactiveTab] = useState();

    useEffect(() => {
        let newTabData = [];
        fetch('/api/datatab', { method: "GET", datatype: "JSON" })
            .then(res => res.json())
            .then(data => {
                data.map(tab => (
                    newTabData.push({
                        tabName: tab.tabName
                    })
                ))
                settabsData(newTabData)
            })
    }, [])

    const handleTab = (e) => {
        settableData([])
        const SelectedTabName = e.target.id;
        setactiveTab(SelectedTabName)
        fetch('/api/data', {method: "GET"})
            .then(res => res.json())
            .then(data => {
                const SelectedData = data.filter(item => item.tabName === SelectedTabName).map(item => item.tabData);
                settableData(SelectedData)
            })
            .catch(error =>{
                console.log('error is ::', error)
            })
    }

    return (
        <react.Fragment>
            <div className="main-div">
                <div className="tabs-main">
                    {tabsData.map((tab, index) => {
                        return <div key={index} className={tab.tabName === activeTab ? "tabs-dynamic active" : "tabs-dynamic"} id={tab.tabName} onClick={(e) => handleTab(e)}>{tab.tabName}</div>
                    })}
                    <div className="tabs">Vol Curve</div>
                    <div className="tabs">Vol Smile</div>
                    <div className="tabs">Heatmaps</div>
                </div>
                <div className="tableData">
                    <table>
                        <thead>
                            <th>Exp Date</th>
                            <th>ATM</th>
                            <th>25d RR</th>
                            <th>10d RR</th>
                            <th>25d BF</th>
                            <th>10d BF</th>
                        </thead>
                        <tbody>
                            {
                               tableData.map(item => {
                                    return item.map((data, index) => {
                                        return <tr key={index}><td>{data.expDate}</td><td>{data.atm}</td><td>{data.twentyFiveDRR}</td><td>{data.tenDRR}</td><td>{data.twentyFiveDBF}</td><td>{data.tenDBF}</td></tr>
                                    })
                                })
                            }
                        </tbody>
                    </table>
                </div>
            </div>
        </react.Fragment>
    )
}
export default TableList