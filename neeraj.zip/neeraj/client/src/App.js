
import react from 'react'
import TableList from './TableList';

function App() {
  return (
    <react.Fragment>
      <TableList />
    </react.Fragment>
  );
}

export default App;
