const express = require('express')

const app = express()

const data =[
    {
        id: 1,
        tabName: 'RR/BF Table',
        tabData:[
            {
                expDate: "5 july, 2021",
                atm: 7.10,
                twentyFiveDRR: -0.2,
                tenDRR: -0.2,
                twentyFiveDBF: -0.2,
                tenDBF: -0.2,
            },
            {
                expDate: "5 july, 2021",
                atm: 7.10,
                twentyFiveDRR: -0.2,
                tenDRR: -0.2,
                twentyFiveDBF: -0.2,
                tenDBF: -0.2,
            },
            {
                expDate: "5 july, 2021",
                atm: 7.10,
                twentyFiveDRR: -0.2,
                tenDRR: -0.2,
                twentyFiveDBF: -0.2,
                tenDBF: -0.2,
            },
        ]
    },
    {
        id: 2,
        tabName: 'Call/Put Table',
        tabData:[
            {
                expDate: "6 july, 2021",
                atm: 8.10,
                twentyFiveDRR: -0.3,
                tenDRR: -0.3,
                twentyFiveDBF: -0.3,
                tenDBF: -0.3,
            },
            {
                expDate: "6 july, 2021",
                atm: 8.10,
                twentyFiveDRR: -0.4,
                tenDRR: -0.4,
                twentyFiveDBF: -0.4,
                tenDBF: -0.4,
            },
            {
                expDate: "6 july, 2021",
                atm: 8.10,
                twentyFiveDRR: -0.4,
                tenDRR: -0.4,
                twentyFiveDBF: -0.4,
                tenDBF: -0.4,
            }
        ]
    },
    {
        id: 3,
        tabName: 'Vol Curve',
        tabData:[
            {
                expDate: "7 july, 2021",
                atm: 9.10,
                twentyFiveDRR: -0.5,
                tenDRR: -0.5,
                twentyFiveDBF: -0.5,
                tenDBF: -0.5,
            },
            {
                expDate: "7 july, 2021",
                atm: 9.10,
                twentyFiveDRR: -0.6,
                tenDRR: -0.6,
                twentyFiveDBF: -0.6,
                tenDBF: -0.7,
            },
            {
                expDate: "7 july, 2021",
                atm: 9.10,
                twentyFiveDRR: -0.7,
                tenDRR: -0.7,
                twentyFiveDBF: -0.7,
                tenDBF: -0.7,
            }
        ]
    },
    {
        id: 4,
        tabName: 'Vol Smile',
        tabData:[
            {
                expDate: "8 july, 2021",
                atm: 1.10,
                twentyFiveDRR: -0.8,
                tenDRR: -0.8,
                twentyFiveDBF: -0.8,
                tenDBF: -0.8,
            },
            {
                expDate: "8 july, 2021",
                atm: 1.10,
                twentyFiveDRR: -0.8,
                tenDRR: -0.8,
                twentyFiveDBF: -0.8,
                tenDBF: -0.8,
            },
            {
                expDate: "8 july, 2021",
                atm: 1.10,
                twentyFiveDRR: -0.9,
                tenDRR: -0.9,
                twentyFiveDBF: -0.9,
                tenDBF: -0.9,
            }
        ]
    },
    {
        id: 5,
        tabName: 'Heatmaps',
        tabData:[
            {
                expDate: "9 july, 2021",
                atm: 2.10,
                twentyFiveDRR: -0.2,
                tenDRR: -0.2,
                twentyFiveDBF: -0.2,
                tenDBF: -0.2,
            },
            {
                expDate: "9 july, 2021",
                atm: 2.10,
                twentyFiveDRR: -0.2,
                tenDRR: -0.2,
                twentyFiveDBF: -0.2,
                tenDBF: -0.2,
            },
            {
                expDate: "9 july, 2021",
                atm: 2.10,
                twentyFiveDRR: -0.2,
                tenDRR: -0.2,
                twentyFiveDBF: -0.2,
                tenDBF: -0.2,
            }
        ]
    }
];

const dataTabName = [
    {
        tabName: 'RR/BF Table', 
    },
    {
        tabName: 'Call/Put Table', 
    },
]

app.get('/api/datatab', (req, res) => {
    res.json(dataTabName)
})
app.get('/api/data', (req, res) => {
    res.json(data)
})

const port = 5000;

app.listen(port, () => console.log(`server started on port ${port}`))
